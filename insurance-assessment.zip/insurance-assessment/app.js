const express = require('express');
const mongoose = require('mongoose');
const multer = require('multer');
const path = require('path');
const osUtils = require('os-utils');
const { Worker } = require('worker_threads');
const scheduleRouter = require('./routes/scheduleRouter');

require('dotenv').config();

const app = express();
app.use(express.json());

// MongoDB connection
mongoose.connect(process.env.MONGO, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => console.log('Mongo connecconnectedted'))
  .catch(err => console.error('Mongo connect error:', err));

// Multer upload
const upload = multer({ dest: path.join(__dirname, 'uploads/') });

// API: Upload CSV/XLSX file
app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).send({ error: 'file missing' });

  const worker = new Worker(path.join(__dirname, 'workers', 'csvWorker.js'), {
    workerData: { filePath: req.file.path }
  });

  worker.on('message', (msg) => res.send(msg));
  worker.on('error', (err) => res.status(500).send({ error: err.message }));
});

// API: Search by username (firstname)
const User = require('./models/User');
const Policy = require('./models/Policy');

app.get('/api/policies/by-user/:firstName', async (req, res) => {
  try {
    const users = await User.find({ firstName: new RegExp('^' + req.params.firstName + '$', 'i') });
    if (!users.length) return res.status(404).send({ error: 'user not found' });

    const results = [];
    for (const user of users) {
      const policies = await Policy.find({ userId: user._id })
        .populate('carrier')
        .populate('lob')
        .populate('agent')
        .lean();
      results.push({ user, policies });
    }
    res.send(results);
  } catch (err) {
    res.status(500).send({ error: err.message });
  }
});

// API: Aggregate policies by user
app.get('/api/policies/aggregate/by-user', async (req, res) => {
  try {
    const agg = await Policy.aggregate([
      {
        $group: {
          _id: '$userId',
          totalPolicies: { $sum: 1 },
          policies: { $push: '$policyNumber' }
        }
      },
      {
        $lookup: {
          from: 'users',
          localField: '_id',
          foreignField: '_id',
          as: 'user'
        }
      },
      { $unwind: '$user' }
    ]);
    res.send(agg);
  } catch (err) {
    res.status(500).send({ error: err.message });
  }
});

// Mount scheduler
app.use('/api', scheduleRouter);

// CPU Monitoring
const CPU_THRESHOLD = 70;
setInterval(() => {
  osUtils.cpuUsage((v) => {
    const pct = v * 100;
    console.log(`CPU usage: ${pct.toFixed(1)}%`);
    if (pct >= CPU_THRESHOLD) {
      console.warn('CPU high, exiting...');
      process.exit(1);
    }
  });
}, 5000);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on ${PORT}`));
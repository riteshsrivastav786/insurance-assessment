const { parentPort, workerData } = require('worker_threads');
const fs = require('fs');
const csv = require('csv-parser');
const mongoose = require('mongoose');

(async () => {
  try {
    await mongoose.connect(process.env.MONGO, { useNewUrlParser: true, useUnifiedTopology: true });

    const Agent = require('../models/Agent');
    const User = require('../models/User');
    const Account = require('../models/Account');
    const LOB = require('../models/LOB');
    const Carrier = require('../models/Carrier');
    const Policy = require('../models/Policy');

    const filePath = workerData.filePath;
    let inserted = 0;

    const stream = fs.createReadStream(filePath).pipe(csv());

    for await (const row of stream) {
      const agentDoc = await Agent.findOneAndUpdate(
        { name: row.agent },
        { name: row.agent },
        { upsert: true, new: true }
      );

      const userDoc = await User.findOneAndUpdate(
        { email: row.email },
        {
          firstName: row.firstname,
          dob: row.dob ? new Date(row.dob) : null,
          address: row.address,
          phone: row.phone,
          state: row.state,
          zip: row.zip,
          email: row.email,
          gender: row.gender,
          userType: row.userType
        },
        { upsert: true, new: true }
      );

      const accountDoc = await Account.findOneAndUpdate(
        { name: row.account_name, userId: userDoc._id },
        { name: row.account_name, userId: userDoc._id },
        { upsert: true, new: true }
      );

      const lobDoc = await LOB.findOneAndUpdate(
        { categoryName: row.category_name },
        { categoryName: row.category_name },
        { upsert: true, new: true }
      );

      const carrierDoc = await Carrier.findOneAndUpdate(
        { companyName: row.company_name },
        { companyName: row.company_name },
        { upsert: true, new: true }
      );

      await Policy.create({
        policyNumber: row.policy_number,
        startDate: row.policy_start_date ? new Date(row.policy_start_date) : null,
        endDate: row.policy_end_date ? new Date(row.policy_end_date) : null,
        userId: userDoc._id,
        carrierId: carrierDoc._id,
        lobId: lobDoc._id,
        agent: agentDoc._id
      });

      inserted++;
    }

    parentPort.postMessage({ inserted });
  } catch (err) {
    parentPort.postMessage({ error: err.message });
  }
})();
const express = require('express');
const router = express.Router();
const schedule = require('node-schedule');
const mongoose = require('mongoose');

const Message = mongoose.model('ScheduledMessage',
  new mongoose.Schema({ message: String, runAt: Date }, { timestamps: true })
);

router.post('/schedule', async (req, res) => {
  const { message, day, time } = req.body;
  if (!message || !day || !time) return res.status(400).send({ error: 'message, day and time required' });

  let runDate;
  const weekdays = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];

  if (weekdays.includes(day.toLowerCase())) {
    const now = new Date();
    const target = weekdays.indexOf(day.toLowerCase());
    const diff = (target + 7 - now.getDay()) % 7 || 7;
    const [h, m] = time.split(':').map(Number);
    runDate = new Date(now.getFullYear(), now.getMonth(), now.getDate() + diff, h, m);
  } else {
    const [h, m] = time.split(':').map(Number);
    const d = new Date(day);
    runDate = new Date(d.getFullYear(), d.getMonth(), d.getDate(), h, m);
  }

  const doc = await Message.create({ message, runAt: runDate });

  const Delivered = mongoose.model('DeliveredMessage',
    new mongoose.Schema({ message: String, deliveredAt: Date })
  );

  schedule.scheduleJob(runDate, async () => {
    await Delivered.create({ message, deliveredAt: new Date() });
    console.log('Delivered:', message);
  });

  res.send({ scheduled: true, runAt: runDate, id: doc._id });
});

module.exports = router;
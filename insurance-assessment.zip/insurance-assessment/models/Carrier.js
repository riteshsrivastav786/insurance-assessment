const { Schema, model } = require('mongoose');

const CarrierSchema = new Schema({
  companyName: String,
  collectionId: String
});

module.exports = model('Carrier', CarrierSchema);
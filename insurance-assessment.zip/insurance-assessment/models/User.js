const { Schema, model } = require('mongoose');

const UserSchema = new Schema({
  firstName: String,
  dob: Date,
  address: String,
  phone: String,
  state: String,
  zip: String,
  email: String,
  gender: String,
  userType: String
}, { timestamps: true });

module.exports = model('User', UserSchema);
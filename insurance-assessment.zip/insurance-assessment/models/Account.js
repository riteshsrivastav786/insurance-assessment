const { Schema, model } = require('mongoose');

const AccountSchema = new Schema({
  name: String,
  userId: { type: Schema.Types.ObjectId, ref: 'User' }
});

module.exports = model('Account', AccountSchema);
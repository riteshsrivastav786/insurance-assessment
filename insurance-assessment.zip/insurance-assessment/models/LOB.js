const { Schema, model } = require('mongoose');

const LOBSchema = new Schema({
  categoryName: String,
  collectionId: String
});

module.exports = model('LOB', LOBSchema);
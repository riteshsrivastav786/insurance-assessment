const { Schema, model } = require('mongoose');

const PolicySchema = new Schema({
  policyNumber: String,
  startDate: Date,
  endDate: Date,
  policyCategoryCollectionId: String,
  companyCollectionId: String,
  userId: { type: Schema.Types.ObjectId, ref: 'User' },
  carrierId: { type: Schema.Types.ObjectId, ref: 'Carrier' },
  lobId: { type: Schema.Types.ObjectId, ref: 'LOB' },
  agent: { type: Schema.Types.ObjectId, ref: 'Agent' }
});

module.exports = model('Policy', PolicySchema);
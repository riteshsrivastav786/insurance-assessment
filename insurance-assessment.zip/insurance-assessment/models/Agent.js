const { Schema, model } = require('mongoose');

const AgentSchema = new Schema({
  name: String,
  producer: String,
  agencyId: String
}, { timestamps: true });

module.exports = model('Agent', AgentSchema);